/*
	STDLIB2.C -- FOR BDS C V1.50 	12/29/82
	COPYRIGHT (C) 1982 BY LEOR ZOLMAN

	THIS FILE CONTAINS THE FOLLOWING LIBRARY FUNCTIONS SOURCES:

	PRINTF 		LPRINTF	*	FPRINTF		SPRINTF		_SPR
	SCANF		FSCANF		SSCANF		_SCN
	FGETS
	PUTS		FPUTS
	SWAPIN

	* --  << NOT YET DOCUMENTED IN THE V1.50 USER'S GUIDE. >>

	NOTE:	THE MAXIMUM OUTPUT LINE LENGTH FOR ALL FORMATTED OUTPUT
		FUNCTIONS IS NOW UNLIMITED, DUE TO SOME NEW TECHNOLOGY,
		ALTHOUGH THE LIMIT OF ANY ONE "FORMAT CONVERSION" IS STILL
		MAXLINE CHARACTERS.

*/

#INCLUDE <BDSCIO.H>

#DEFINE DEV_LST 2		/* LIST DEVICE FOR LPRINTF */

CHAR TOUPPER(), ISDIGIT();

PRINTF(FORMAT)
CHAR *FORMAT;
{
	INT PUTCHAR();
	RETURN _SPR(&FORMAT, &PUTCHAR);	/* USE "_SPR" TO FORM THE OUTPUT */
}

INT LPRINTF(FORMAT)
CHAR *FORMAT;
{
	INT _FPUTC();
	RETURN _SPR(&FORMAT, &_FPUTC, DEV_LST);
}

SPRINTF(BUFFER,FORMAT)
CHAR *BUFFER, *FORMAT;
{
	INT _SSPR();
	_SPR(&FORMAT, &_SSPR, &BUFFER);	/* CALL _SPR TO DO ALL THE WORK */
	*BUFFER = '\0';
}

_SSPR(C,STRPTR)
CHAR **STRPTR;
{
	*(*STRPTR)++ = C;
}

INT FPRINTF(IOBUF,FORMAT)
CHAR *FORMAT;
FILE *IOBUF;
{
	INT _FPUTC();
	RETURN _SPR(&FORMAT, &_FPUTC, IOBUF);
}

INT _FPUTC(C,IOBUF)
{
	IF (C == '\N')
		IF (PUTC('\R',IOBUF) == ERROR)
			RETURN ERROR;
	IF (PUTC(C,IOBUF) == ERROR)
		RETURN ERROR;
	RETURN OK;
}	

INT SCANF(FORMAT)
CHAR *FORMAT;
{
	CHAR LINE[MAXLINE];
	GETS(LINE);			/* GET A LINE OF INPUT FROM USER */
	RETURN _SCN(LINE,&FORMAT);	/* AND SCAN IT WITH "_SCN"	 */
}

INT SSCANF(LINE,FORMAT)
CHAR *LINE, *FORMAT;
{
	RETURN _SCN(LINE,&FORMAT);	/* LET _SCN DO ALL THE WORK */
}


INT FSCANF(IOBUF,FORMAT)
CHAR *FORMAT;
FILE *IOBUF;
{
	CHAR TEXT[MAXLINE];
	IF (!FGETS(TEXT,IOBUF))
		RETURN ERROR;
	RETURN _SCN(TEXT,&FORMAT);
}


_SPR(FMT,PUTCF,ARG1)
INT (*PUTCF)();
CHAR **FMT;
{
	CHAR _USPR(), C, BASE, *SPTR, *FORMAT;
	CHAR WBUF[MAXLINE], *WPTR, PF, LJFLAG, ZFFLAG;
	INT WIDTH, PRECISION,  *ARGS;

	FORMAT = *FMT++;    /* FMT FIRST POINTS TO THE FORMAT STRING	*/
	ARGS = FMT;	    /* NOW FMT POINTS TO THE FIRST ARG VALUE	*/

	WHILE (C = *FORMAT++)
	  IF (C == '%') {
	    WPTR = WBUF;
	    PRECISION = 6;
	    LJFLAG = PF = ZFFLAG = 0;

	    IF (*FORMAT == '-') {
		    FORMAT++;
		    LJFLAG++;
	     }


	    IF (*FORMAT == '0') ZFFLAG++;	/* TEST FOR ZERO-FILL */

	    WIDTH = (ISDIGIT(*FORMAT)) ? _GV2(&FORMAT) : 0;

	    IF ((C = *FORMAT++) == '.') {
		    PRECISION = _GV2(&FORMAT);
		    PF++;
		    C = *FORMAT++;
	     }

	    SWITCH(TOUPPER(C)) {

		CASE 'D':  IF (*ARGS < 0) {
				*WPTR++ = '-';
				*ARGS = -*ARGS;
				WIDTH--;
			    }

		CASE 'U':  BASE = 10; GOTO VAL;

		CASE 'X':  BASE = 16; GOTO VAL;

		CASE 'O':  BASE = 8;  /* NOTE THAT ARBITRARY BASES CAN BE
				         ADDED EASILY BEFORE THIS LINE */

		     VAL:  WIDTH -= _USPR(&WPTR,*ARGS++,BASE);
			   GOTO PAD;

		CASE 'C':  *WPTR++ = *ARGS++;
			   WIDTH--;
			   GOTO PAD;

		CASE 'S':  IF (!PF) PRECISION = 200;
			   SPTR = *ARGS++;
			   WHILE (*SPTR && PRECISION) {
				*WPTR++ = *SPTR++;
				PRECISION--;
				WIDTH--;
			    }

		     PAD:  *WPTR = '\0';
		     PAD2: WPTR = WBUF;
			   IF (!LJFLAG)
				WHILE (WIDTH-- > 0)
					IF ((*PUTCF)(ZFFLAG ? '0' : ' ',ARG1)
						== ERROR) RETURN ERROR;;

			   WHILE (*WPTR)
				IF ((*PUTCF)(*WPTR++,ARG1) == ERROR) 
					RETURN ERROR;

			   IF (LJFLAG)
				WHILE (WIDTH-- > 0)
					IF ((*PUTCF)(' ',ARG1) == ERROR)
						RETURN ERROR;
			   BREAK;

		CASE NULL:
			   RETURN OK;

		DEFAULT:   IF ((*PUTCF)(C,ARG1) == ERROR)
				RETURN ERROR;
	     }
	  }
	  ELSE IF ((*PUTCF)(C,ARG1) == ERROR)
			RETURN ERROR;
	RETURN OK;
}

/*
	INTERNAL ROUTINE USED BY "_SPR" TO PERFORM ASCII-
	TO-DECIMAL CONVERSION AND UPDATE AN ASSOCIATED POINTER:
*/

INT _GV2(SPTR)
CHAR **SPTR;
{
	INT N;
	N = 0;
	WHILE (ISDIGIT(**SPTR)) N = 10 * N + *(*SPTR)++ - '0';
	RETURN N;
}

CHAR _USPR(STRING, N, BASE)
CHAR **STRING;
UNSIGNED N;
{
	CHAR LENGTH;
	IF (N<BASE) {
		*(*STRING)++ = (N < 10) ? N + '0' : N + 55;
		RETURN 1;
	}
	LENGTH = _USPR(STRING, N/BASE, BASE);
	_USPR(STRING, N%BASE, BASE);
	RETURN LENGTH + 1;
}


/*
	GENERAL FORMATTED INPUT CONVERSION ROUTINE:
*/

INT _SCN(LINE,FMT)
CHAR *LINE, **FMT;
{
	CHAR SF, C, BASE, N, *SPTR, *FORMAT;
	INT SIGN, VAL, **ARGS;

	FORMAT = *FMT++;	/* FMT FIRST POINTS TO THE FORMAT STRING */
	ARGS = FMT;		/* NOW IT POINTS TO THE ARG LIST */

	N = 0;
	WHILE (C = *FORMAT++)
	{
	   IF (ISSPACE(C)) CONTINUE;	/* SKIP WHITE SPACE IN FORMAT STRING */
	   IF (C != '%')		/* IF NOT %, MUST MATCH TEXT */
	    {
		IF (C != _IGS(&LINE)) RETURN N;
		ELSE LINE++;
	    }
	   ELSE		/* PROCESS CONVERSION */
	    {
		SIGN = 1;
		BASE = 10;
		SF = 0;
		IF ((C = *FORMAT++) == '*')
		 {
			SF++;		/* IF "*" GIVEN, SUPRESS ASSIGNMENT */
			C = *FORMAT++;
		 }
		SWITCH (TOUPPER(C))
		 {
		   CASE 'X': BASE = 16;
			     GOTO DOVAL;

		   CASE 'O': BASE = 8;
			     GOTO DOVAL;

		   CASE 'D': IF (_IGS(&LINE) == '-') {
				SIGN = -1;
				LINE++;
			      }

	   DOVAL:  CASE 'U': VAL = 0;
			     IF (_BC(_IGS(&LINE),BASE) == ERROR)
				RETURN N;
			     WHILE ((C = _BC(*LINE++,BASE)) != 255)
				VAL = VAL * BASE + C;
			     LINE--;
			     BREAK;

		   CASE 'S': _IGS(&LINE);
			     SPTR = *ARGS;
			     WHILE (C = *LINE++)   {
				IF (C == *FORMAT) {
					FORMAT++;
					BREAK;
				 }
				IF (!SF) *SPTR++ = C;
			      }				
			     IF (!SF) {
				N++;
				*SPTR = '\0';
				ARGS++;
			      }
			     CONTINUE;

		   CASE 'C': IF (!SF) {
				POKE(*ARGS++, *LINE);
				N++;
			     }
			     LINE++;
			     CONTINUE;

		   DEFAULT:  RETURN N;
		 }
		IF (!SF)
		 {
			**ARGS++ = VAL * SIGN;
			N++;
		 }
	    }
	   IF (!*LINE) RETURN N;	/* IF END OF INPUT STRING, RETURN */
	}
	RETURN N;
}

CHAR _IGS(SPTR)
CHAR **SPTR;
{
	CHAR C;
	WHILE (ISSPACE(C = **SPTR)) ++*SPTR;
	RETURN (C);
}

INT _BC(C,B)
CHAR C,B;
{
	IF (ISALPHA(C = TOUPPER(C))) C -= 55;
         ELSE  IF (ISDIGIT(C))  C -= 0X30;
	 ELSE RETURN ERROR;
	IF (C > B-1) RETURN ERROR;
		ELSE RETURN C;
}

PUTS(S)
CHAR *S;
{
	WHILE (*S) PUTCHAR(*S++);
}


CHAR *FGETS(S,IOBUF)
CHAR *S;
FILE *IOBUF;
{
	INT COUNT, C;
	CHAR *CPTR;
	COUNT = MAXLINE - 2;
	CPTR = S;
	IF ( (C = GETC(IOBUF)) == CPMEOF || C == EOF) RETURN NULL;

	DO {
		IF ((*CPTR++ = C) == '\N') {
		  IF (CPTR>S+1 && *(CPTR-2) == '\R')
			*(--CPTR - 1) = '\N';
		  BREAK;
		}
	 } WHILE (COUNT-- && (C=GETC(IOBUF)) != EOF && C != CPMEOF);

	IF (C == CPMEOF) UNGETC(C,IOBUF);	/* PUSH BACK CONTROL-Z */
	*CPTR = '\0';
	RETURN S;
}


FPUTS(S,IOBUF)
CHAR *S;
FILE *IOBUF;
{
	CHAR C;
	WHILE (C = *S++) {
		IF (C == '\N') PUTC('\R',IOBUF);
		IF (PUTC(C,IOBUF) == ERROR) RETURN ERROR;
	}
	RETURN OK;
}

SWAPIN(NAME,ADDR)
CHAR *NAME;
{
	INT FD;
	IF (( FD = OPEN(NAME,0)) == ERROR)
		RETURN ERROR;

	IF ((READ(FD,ADDR,512)) < 0) {
		CLOSE(FD);
		RETURN ERROR;
	}

	CLOSE(FD);
	RETURN OK;
}

