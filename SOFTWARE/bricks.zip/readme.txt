CRISS CP/M DIY Computer

http://criss.fun
http://criss.radio.ru
https://hackaday.io/project/181038

Classic Breakout action game fromo Marco. 
Was found in thew Internet and adopted for CRISS CP/M with few changes.

Run mode: CRISS

Original source code is here: 
https://github.com/marcosretrobits/EVAS10N.PAS

Read more about the project here:
https://retrobits.altervista.org/blog/2020/06/evas10n-pas-a-turbo-pascal-rewrite-of-evas10n/


