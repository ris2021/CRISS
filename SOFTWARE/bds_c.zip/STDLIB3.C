/*  File DEFF3.C functions 
    Kalinin Alexandr  5/12/88 */

/*  CLS          LOC          REPEAT      STRING       SLINE
    CON          COFF





								*/

#define NORM_CODE	0
#define ADD_CODE	1
#define SUB_CODE	2
#define MULT_CODE	3
#define DIV_CODE	4
#define FTOA_CODE	5
#define ERROR		-1
#define MAXLINE		128
int loc(x,y)
{
	bios(4 , 27);
	bios(4 , x + 0200);
	bios(4 , y + 0200);
}

cls()
{
	bios(4, 12);
}

string(x,y)
int x;
char y;
{
	while((x--)>0)
	putchar(y);
}

repeat()
{
	main();
}

con()
{
	bios(4,130);
}

coff()
{
	bios(4,131);
}

sline(c,pos,dl)
int c,pos,dl;
{
	int a;
	for(a=pos;a<(pos+dl+1);a++)
	poke(0xf7ff+a,c);
}

fpcomp(op1,op2)
	char *op1,*op2;
{
	char work[5];
	fpsub(work,op1,op2);
	if (work[3] > 127) return (-1);
	if (work[0]+work[1]+work[2]+work[3]) return (1);
	return (0);
}

fpnorm(op1) char *op1;
{	fp(NORM_CODE,op1,op1);return(op1);}

fpadd(result,op1,op2)
	char *result,*op1,*op2;
{	fp(ADD_CODE,result,op1,op2);return(result);}

fpsub(result,op2,op1)
	char *result,*op1,*op2;
	{fp(SUB_CODE,result,op1,op2);return(result);}

fpmult(result,op1,op2)
	char *result,*op1,*op2;
{	fp(MULT_CODE,result,op1,op2);return(result);}

fpdiv(result,op1,op2)
	char *result,*op1,*op2;
{	fp(DIV_CODE,result,op1,op2);return(result);}

atof(fpno,s)
	char fpno[5],*s;
{
	char *fpnorm(),work[5],ZERO[5],FP_10[5];
	int sign_boolean,power;

	initb(FP_10,"0,0,0,80,4");
	setmem(fpno,5,0);
	sign_boolean=power=0;

	while (*s==' ' || *s=='\t') ++s;
	if (*s=='-'){sign_boolean=1;++s;}
	for (;isdigit(*s);++s){
		fpmult(fpno,fpno,FP_10);
		work[0]=*s-'0';
		work[1]=work[2]=work[3]=0;work[4]=31;
		fpadd(fpno,fpno,fpnorm(work));
	}
	if (*s=='.'){
		++s;
		for (;isdigit(*s);--power,++s){
			fpmult(fpno,fpno,FP_10);
			work[0]=*s-'0';
			work[1]=work[2]=work[3]=0;work[4]=31;
			fpadd(fpno,fpno,fpnorm(work));
		}
	}
	if (toupper(*s) == 'E') {++s; power += atoi(s); }
	if (power>0)
		for (;power!=0;--power) fpmult(fpno,fpno,FP_10);
	else
	if (power<0)
		for (;power!=0;++power) fpdiv(fpno,fpno,FP_10);
	if (sign_boolean){
		setmem(ZERO,5,0);
		fpsub(fpno,ZERO,fpno);
	}
	return(fpno);
}
ftoa(result,op1)
	char *result,*op1;
{	fp(FTOA_CODE,result,op1);return(result);}

itof(op1,n)
char *op1;
int n;
{
	char temp[20];
	return atof(op1, itoa(temp,n));
}

itoa(str,n)
char *str;
{
	char *sptr;
	sptr = str;
	if (n<0) { *sptr++ = '-'; n = -n; }
	_uspr(&sptr, n, 10);
	*sptr = '\0';
	return str;
}

print(format)
char *format;
{
	int putchar();
	_spr1(&format, &putchar);
}


_spr1(fmt,putcf,arg1)
int (*putcf)();
char **fmt;
{
	char _uspr(), c, base, *sptr, *format;
	char wbuf[MAXLINE], *wptr, pf, ljflag, zfflag;
	int width, precision, exp, *args;

	format = *fmt++;	/* fmt first points to the format string */
	args = fmt;		/* now fmt points to the first arg value */
	while (c = *format++)
	  if (c == '%') {
	    wptr = wbuf;
	    precision = 6;
	    ljflag = pf = zfflag = 0;

	    if (*format == '-') {
		    format++;
		    ljflag++;
	     }

	    if (*format == '0') zfflag++;	/* test for zero fill */

	    width = isdigit(*format) ? _gv2(&format) : 0;

	    if ((c = *format++) == '.') {
		    precision = _gv2(&format);
		    pf++;
		    c = *format++;
	     }

	    switch(toupper(c)) {
		case 'E':  if (precision>7) precision = 7;
			   ftoa(wbuf,*args++);
			   strcpy(wbuf+precision+3, wbuf+10);
			   width -= strlen(wbuf);
			   goto pad2;

		case 'F':  ftoa(&wbuf[60],*args++);
			   sptr = &wbuf[60];
			   while ( *sptr++ != 'E')
				;
			   exp = atoi(sptr);
			   sptr = &wbuf[60];
			   if (*sptr == ' ') sptr++;
			   if (*sptr == '-') {
				*wptr++ = '-';
				sptr++;
				width--;
			    }
			   sptr += 2;

			   if (exp < 1) {
				*wptr++ = '0';
				width--;
			    }

			   pf = 7;
			   while (exp > 0 && pf) {
				*wptr++ = *sptr++;
				pf--;
				exp--;
				width--;
			    }

			   while (exp > 0) {
				*wptr++ = '0';
				exp--;
				width--;
			    }

			   *wptr++ = '.';
			   width--;

			   while (exp < 0 && precision) {
				*wptr++ = '0';
				exp++;
				precision--;
				width--;
			    }

			   while (precision && pf) {
				*wptr++ = *sptr++;
				pf--;
				precision--;
				width--;
			    }

			   while (precision>0) {
				*wptr++ = '0';
				precision--;
				width--;
			    }

			   goto pad;


		case 'D':  if (*args < 0) {
				*wptr++ = '-';
				*args = -*args;
				width--;
			    }
		case 'U':  base = 10; goto val;

		case 'X':  base = 16; goto val;

		case 'O':  base = 8;

		     val:  width -= _uspr(&wptr,*args++,base);
			   goto pad;

		case 'C':  *wptr++ = *args++;
			   width--;
			   goto pad;

		case 'S':  if (!pf) precision = 200;
			   sptr = *args++;
			   while (*sptr && precision) {
				*wptr++ = *sptr++;
				precision--;
				width--;
			    }

		     pad:  *wptr = '\0';
		     pad2: wptr = wbuf;
			   if (!ljflag)
			    while (width-- > 0)
				if ((*putcf)(zfflag ? '0' : ' ',arg1) == ERROR)
					return ERROR;

			    while (*wptr)
				if ((*putcf)(*wptr++, arg1) == ERROR)
					return ERROR;

			    if (ljflag)
			     while (width-- > 0)
				if ((*putcf)(' ', arg1) == ERROR)
					return ERROR;
			   break;

		 default:  if ((*putcf)(c, arg1) == ERROR)
				return ERROR;
	     }
	  }
	  else if ((*putcf)(c, arg1) == ERROR)
		return ERROR;
}

char *itol(result,n)			
char *result;
int n;
{
return(long(0,result,n));
}

int ltoi(l)				
char l[];
{
return(l[3] + (l[2] << 8));
}

lcomp(op1,op2)				
char *op1,*op2;
{
return(long(1,op1,op2));
}

char *ladd(result,op1,op2)		
char *result,*op1,*op2;
{
return(long(2,result,op1,op2));
}

char *lsub(result,op1,op2)		
char *result,*op1,*op2;
{
return(long(3,result,op1,op2));
}

char *lmul(result,op1,op2)		
char *result,*op1,*op2;
{
return(long(4,result,op1,op2));
}

char *ldiv(result,op1,op2)		
char *result,*op1,*op2;
{
return(long(5,result,op1,op2));
}

char *lmod(result,op1,op2)		
char *result,*op1,*op2;
{
return(long(6,result,op1,op2));
}


char *atol(result,s)			
char *result,*s;
{
char ten[4], temp[4], sign;

itol(ten,10); itol(result,0);

if(sign=(*s == '-')) s++;

while(isdigit(*s))
  ladd(result,lmul(result,result,ten),itol(temp,*s++ - '0'));

return(sign? lsub(result,itol(temp,0),result) : result);
}

char *ltoa(result,op1)				
char *result,*op1;
{
char absval[4], temp[4];
char work[15], *workptr, sign;
char ten[4], zero[4], *rptr;

rptr = result;
itol(ten,10); itol(zero,0);

if(sign = *op1 & 0x80)	
  {
  *rptr++ = '-';
  lsub(absval,zero,op1);
  }
else lassign(absval,op1);

*(workptr = work+14) = '\0';	
do					
  *(--workptr) = '0'+ *(lmod(temp,absval,ten) + 3);
while
  (lcomp(ldiv(absval,absval,ten),zero) > 0);

strcpy(rptr,workptr);
return(result);
}

char *lassign(ldest,lsource)
unsigned *ldest, *lsource;
{
*ldest++ = *lsource++;	
*ldest = *lsource;	
return(ldest);
}

unsigned ltou(l)
char l[];
{
return(l[3] + (l[2] << 8));
}

utol(l,u)
char l[];
unsigned u;
{
itol(l, u & 0x7FFF);	
if(u > 0x7FFF) l[2] += 0x80;
return(l);
}
